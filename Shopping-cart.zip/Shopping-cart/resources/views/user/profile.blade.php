@extends('layouts.master')

@section('content')
    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <h1>Profile Page</h1>
            
        </div>
    </div>    
@endsection