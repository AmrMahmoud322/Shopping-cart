<?php


class Feedback {

    private $host = "";
    private  $username = "";
    private  $password = "";
    private  $conn = "";
    private  $sql ="";
    private $dbname ="software";
            
    function __construct() {
        
        $this->host='localhost';
        $this->dbname= "software";
        $this->username = 'root';
        $this->password = '';
   
    }
   
            
function SendFeedback ($name , $email , $comment , $rating){
    try{
     
     
     
     $conn = mysqli_connect($this->host, $this->username, $this->password);
        mysqli_select_db($conn, $this->dbname);
        
    $this->sql = "INSERT INTO `feedback` (Name, Email, Content , Rating)
    VALUES ('".$name."' , '".$email."', '".$comment."' , '".$rating."')";
   
    
    $result = mysqli_query($conn, $this->sql);
    
    if ($result)
    {
        
    }
    else {
        echo 'failed to send feedback';
    }
    } 
    catch (Exception $ex) {
      
        echo 'Failed to connect with database ' . $ex->getMessage();
    }
    
    
    }
    
    function ViewFeedback(){

     
         if(isset($_POST['show'])){
             
         
        $this->conn = mysqli_connect($this->host, $this->username, $this->password);
        mysqli_select_db($this->conn, $this->dbname);
        
        $query = "SELECT * FROM `feedback` WHERE 1";
        
        if($run= mysqli_query($this->conn,$query))//excution statement
        {
            
            $row=array();
            if($run->num_rows>0)
            {
               echo "<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Comment</th><th>Rate</th></tr> ";
                $count = 0;
                while ($row[] = mysqli_fetch_assoc($run)) {
              
              echo "<tr><td>" . $row[$count]["ID"]. "</td><td>" . $row[$count]["Name"]. "</td><td>" . $row[$count]["Email"]. "</td><td>" . $row[$count]["Content"] . "</td><td>" . $row[$count]["Rating"] . "</td></tr>";
               
             $count++;
               }
     echo "</table>";
            }
             else {
                echo 'No feedback was sent to show';
            }
            }
            
           
        
         }
        
    }

}
