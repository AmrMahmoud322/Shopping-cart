<?php

include_once '../Database/Database_class';

class User_Queries{
    //put your code here
    private $DB;
    
    function __construct() {
        $this->DB = new Database_class();
    }


   public function reserve_ticket($pname,$pid,$pssn,$pemail,$year,$month,$day,$hours,$minutes,$seconds){
        $ticket = array('pname'=>$pname,'id'=>$pid,'ssn'=>$pssn,'email'=>$pemail,'year'=>$year,'month'=>$month,'day'=>$day,'hours'=>$hours,'minutes'=>$minutes,'seconds'=>$seconds);
        $result = $this->DB->insert('tickets',$ticket);
        if($result)
            return true;
        else
            return false;
   }


   public function view_train($source,$destination,$year,$month,$day){
       if($source == NULL  && $destination == NULL && $year == NULL && $month == NULL && $day == NULL)
           throw new Exception("D5l data ya 3'by");
       else if($source != NULL  && $destination == NULL && $year == NULL && $month == NULL && $day == NULL)
       {
           $query = "SELECT * FROM 'trains' WHERE source = '$source'";
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       }else if($source != NULL  && $destination != NULL && $year == NULL && $month == NULL && $day == NULL){
           $query = "SELECT * FROM 'trains' WHERE source = '$source' AND destination = '$destination'";
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       }else if($source != NULL  && $destination != NULL && $year != NULL && $month == NULL && $day == NULL){
            $query = "SELECT * FROM 'trains' WHERE source = '$source' AND destination = '$destination' AND year = '$year'";
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       }else if($source != NULL  && $destination != NULL && $year != NULL && $month != NULL && $day == NULL){
            $query = "SELECT * FROM 'trains' WHERE source = '$source' AND destination = '$destination' AND year = '$year' AND month = '$month'"; 
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       } else {
            $query = "SELECT * FROM 'trains' WHERE source = '$source' AND destination = '$destination' AND year = '$year' AND month = '$month' AND day = '$day'"; 
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       }
   }    
   public function view_ticket($tid){
       $query = "SELECT * FROM 'reserved_ticket' where id = '$tid'";
       $ticket_data=$this->DB->get_row($query);
        return $ticket_data;
   }
  /*
   * method cancel l tickt ht4el l tivket mn l trserved ticket
   */
   public function cancel_ticket($tid){
     $query = "DELETE FROM 'reserved_ticket' WHERE id = '$tid'";
     $query_run = mysqli_run($query);
     if($query_run)
         return true;
     else {
         throw new Exception("nta nsab 4klk keda mef4 ticket b l id dah ay nsab");
     }
   }
   /*
    * 3ndna b2a l method de l httl3 kol l train 3la 7asab l date  
    */
   public function get_train_date($year,$month,$day){
       $query = "SELECT * FROM 'trains' WHERE year = '$year' AND month = '$month' AND day = '$day'";
       $train_data = $this->DB->get_row($query);
       return $train_data;
   }

   public function edit_user($ssn, $fname, $lname, $email, $phone, $password,$id){
       $udata = array('ssn'=>$ssn,'fname'=>$fname,'lname'=>$lname,'email'=>$email,'phone'=>$phone,'password'=>$password);
       $result = $this->DB->update('customers',$udata,$id);
       if($result)
           return true;
       else
           return false;
   }


    
}
