<?php
    include_once '../soft/Clerk.php';
    include_once '../soft/Admin.php';
                        if(isset($_POST['c_fname'])
                        && isset($_POST['c_lname'])
                        && isset($_POST['c_email'])
                        && isset($_POST['c_phone'])
                        && isset($_POST['c_password'])
                        && isset($_POST['c_repassword'])
                        && isset($_POST['c_salary'])){
                            $c_fname = $_POST['c_fname'];
                            $c_lname = $_POST['c_lname'];
                            $c_email = $_POST['c_email'];
                            $c_phone = $_POST['c_phone'];
                            $c_password = $_POST['c_password'];
                            $c_rpassword = $_POST['c_repassword'];
                            $c_salary = $_POST['c_salary'];



                                $admin = new Admin();
                                $clerk = new Clerk();

                                 $clerk->setFname($c_fname);
                                 $clerk->setLname($c_lname);
                                 $clerk->setEmail($c_email);
                                 $clerk->setPhone($c_phone);
                                 $clerk->setPassword($c_password);
                                 $clerk->setSalary($c_salary);

                              if($admin->add_clerk($clerk)){
                                echo 'ay 7aga';
                              }else{
                               header("location: ../train-system/admin.php");
                              }

                        }

                              ?>