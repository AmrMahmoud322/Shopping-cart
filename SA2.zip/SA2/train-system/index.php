<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>main page</title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/passenger.css">
    <link rel="stylesheet" href="css/home-page.css">
  </head>
  <body>
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/click.js"></script>
    <header>
       <nav>
         <div class="container">
             <div class="logo">
               <h2><span>Citizen</span> Service</h2>
             </div>
             <a href="login-and-register.php"><input type="button" class="login" name="login" value="login or Register"></a>
         </div>
         <div class="clear-float"></div>
       </nav>
       <div class="container">
         <div class="search-about-trains">
           <div class="inputs">
             <form class="" action="index.php" method="post">
             <!-- leaving from      -->
               <div class="leaving-from">
                 <label>Leaving From:</label>
                 <select >
                    <option >- Select City -  </option>
                    <option>Cairo </option>
                    <option>Alex </option>
                    <option>Asuit </option>
                    <option>Souhag </option>
                    <option>Aswan </option>
                    <option>Tanta </option>
                 </select>
               </div>
               <!-- going to -->
               <div class="leaving-from">
                 <label>Going To:</label>
                 <select >
                    <option >- Select City -  </option>
                    <option>Cairo </option>
                    <option>Alex </option>
                    <option>Asuit </option>
                    <option>Souhag </option>
                    <option>Aswan </option>
                    <option>Tanta </option>
                 </select>
               </div>
               <label>Date:</label>
               <input type="date" class="date" name="date" value="">
               <input type="button" class="submit" name="search" value="Search" id="search-for-trains">
               </form>
               <!-- ======== view removed train ======= -->
               <div id="trains-details" class="trains-details ">
                 <span class="close">X</span>
                  <h2> Trains Avilable</h2>
                    <div class="cc">
                       <table class="trains-details-table" >
                         <tr>
                           <th>Train's ID</th>
                           <th>Train's Number</th>
                           <th>Go From</th>
                           <th>Go To</th>
                           <th>Time</th>
                           <th>Date</th>
                         </tr>
                         <tr>
                           <td>#</td>
                           <td>#</td>
                           <td>#</td>
                           <td>#</td>
                           <td>#</td>
                           <td>#</td>
                           <td class="colo-reserve"><button type="button" name="reserve" >Reserve</button></td>
                         </tr>
                       </table>
                    </div>
               </div>
               <!-- ============ -->
           </div>
         </div>
       </div>
    </header>
    <footer>
      <div class="container">
        <div class="left-footer">Copyright (c) 2017 All Rights Reserved To <span>FCI-H.</span></div>
         <div class="center-footer">
           <h4>Follow Us:</h4>
            <i class="fa fa-facebook" aria-hidden="true"></i>
            <i class="fa fa-google-plus" aria-hidden="true"></i>
            <i class="fa fa-twitter" aria-hidden="true"></i>
            <i class="fa fa-linkedin" aria-hidden="true"></i>
         </div>
        <div class="right-footer">Designed By <span>Citizen Service</span>  Team</div>
        <div class="clear-float"></div>
      </div>
    </footer>
  </body>
</html>
