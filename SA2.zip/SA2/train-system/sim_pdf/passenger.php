	<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Passenger Page</title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/home-page.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/passenger.css">
  </head>
  <body>
    <script src="js/jquery-1.11.3.min.js"></script>
    <script src="js/click.js"></script>
     <header>
        <nav>
          <div class="container">
              <div class="logo">
                <h2><span>Citizen</span> Service</h2>
              </div>
                 <h1>Welcome</h1>
          </div>
        </nav>
     </header>
     <!-- main -->
     <main>
        <section class="jobs">
           <div class="container">
             <h2>What Do You Want To Do</h2>
                <a href="#" class="a-search" style="background-color:#00f">Search</a>
                <a href="#" class="a-view-time-table">View Time Table</a>
                <a href="#" class="a-update-ticket">Update Ticket</a>
                <a href="#" class="a-cancel-ticket">Cancel Ticket</a>
                <a href="#" class="a-pay">Pay</a>
                <a href="#" class="a-rate">Rate</a>
                <a href="#" class="a-complane">Complane</a>
                <a href="#" class="a-update-profile">Update Profile</a>
          </div>
       </section>
       <!-- serach  option-->
     <div class="container">
       <div class="search-about-trains all search" style="display:block">
         <span class="close">X</span>
         <div class="inputs">
           <form class="" action="index.php" method="post">
           <!-- leaving from      -->
             <div class="leaving-from">
               <label>Leaving From:</label>
               <select >
                  <option >- Select City -  </option>
                  <option>Cairo </option>
                  <option>Alex </option>
                  <option>Asuit </option>
                  <option>Souhag </option>
                  <option>Aswan </option>
                  <option>Tanta </option>
               </select>
             </div>
             <!-- going to -->
             <div class="leaving-from">
               <label>Going To:</label>
               <select >
                  <option >- Select City -  </option>
                  <option>Cairo </option>
                  <option>Alex </option>
                  <option>Asuit </option>
                  <option>Souhag </option>
                  <option>Aswan </option>
                  <option>Tanta </option>
               </select>
             </div>
             <label>Date:</label>
             <input type="date" class="date" name="date" value="">
             <input type="button" class="submit" name="search" value="Search" id="search-for-trains">
             </form>
             <!-- ======== result of search  ======= -->
             <div id="trains-details" class="trains-details ">
                <h2> Trains Avilable</h2>
                  <div class="cc">
                     <table class="trains-details-table" >
                       <tr>
                         <th>Train's ID</th>
                         <th>Train's Number</th>
                         <th>Go From</th>
                         <th>Go To</th>
                         <th>Time</th>
                         <th>Date</th>
                       </tr>
                       <tr>
                         <td>#</td>
                         <td>#</td>
                         <td>#</td>
                         <td>#</td>
                         <td>#</td>
                         <td>#</td>
                         <td class="colo-reserve"><button type="button" name="reserve">Reserve</button></td>
                       </tr>
                     </table>
                  </div>
             </div>
         </div>
       </div>
       <!-- == end search ========== -->
       <!-- ======== view time table ======= -->
       <div  class=" all search view-time-table" >
            <span class="close">X</span>
          <h2> Trains Avilable</h2>
           <form action="../Connectinghtml/view_time_table.php" method="post">
               <input type="submit" value="view" name="view">
           </form>

            <div class="cc">
               <table class="trains-details-table" >
                 <tr>
                   <th>Train's ID</th>
                   <th>Train's Number</th>
                   <th>Go From</th>
                   <th>Go To</th>
                   <th>Time</th>
                   <th>Date</th>
                 </tr>
                 <tr>
                   <td>#</td>
                   <td>#</td>
                   <td>#</td>
                   <td>#</td>
                   <td>#</td>
                   <td>#</td>
                   <td class="colo-reserve"><button type="button" name="reserve">Reserve</button></td>
                 </tr>
               </table>
            </div>
       </div>
       <!-- end view time table -->
        <!-- ================ start update ticket =========== -->
        <div class=" container all delete-user update-ticket">
          <span class="close">X</span>
          <div class="">
               <input type="text" name="search" placeholder="Enter Ticket's ID">
               <label>OR</label>
               <input type="email" name="search" placeholder="Enter Your email">
               <button type="submit" name="button" id="find-ticket-buttom">Find Ticket</button>
          </div>
               <div class="search add-train update-ticket-options">
                 <span class="close">X</span>
                 <div class="inputs">
                   <form class="" action="index.php" method="post">
                   <!-- leaving from      -->
                     <div class="leaving-from">
                       <label>Leaving From:</label>
                       <select >
                          <option >- Select City -  </option>
                          <option>Cairo </option>
                          <option>Alex </option>
                          <option>Asuit </option>
                          <option>Souhag </option>
                          <option>Aswan </option>
                          <option>Tanta </option>
                       </select>
                     </div>
                     <!-- going to -->
                     <div class="leaving-from">
                       <label>Going To:</label>
                       <select >
                          <option >- Select City -  </option>
                          <option>Cairo </option>
                          <option>Alex </option>
                          <option>Asuit </option>
                          <option>Souhag </option>
                          <option>Aswan </option>
                          <option>Tanta </option>
                       </select>
                     </div>
                     <label>Date:</label>
                     <input type="date" class="date" name="date" value="">
                     <!-- time -->
                     <div class="leaving-from time" >
                       <label >Time:</label>
                       <select >
                          <option >- Select Time -  </option>
                          <option># </option>
                          <option># </option>
                          <option># </option>
                          <option># </option>
                          <option># </option>
                          <option># </option>
                       </select>
                     </div>
                     <input  type="submit" class="submit" name="search" value="Update">
                     </form>
                 </div>
               </div>
           </div>
              <!-- end update ticket -->
          <!-- ============= start cancel ticket -=========== -->
          <div class="all search delete-user cancel-ticket">
            <span class="close">X</span>
              <form action="../Connectinghtml/cancel_ticket.php" method="post">
               <input type="text" name="tnum" placeholder="Write Ticket's Number">
               <label style="display:inline-block">And</label>
               <input type="email" name="umail" placeholder="Write email">
               <input type="submit" name="cancel" value="Cancel">
              </form>

          </div>
            <!-- end cancel ticket         -->
      <!-- ========= start pay ====== -->
               <div class="all search pay">
                   <form action="https://secure.paypal.com/uk/cgi-bin/webscr" method="post" name="paypal" id="paypal">
                    <!-- Prepopulate the PayPal checkout page with customer details, -->
                          <div class="left-section-pay">
                              <input type="text" name="name" placeholder="First Name" required>
                              <input type="text" name="name" placeholder="Last Name" required>
                              <input type="text" name="address" placeholder="Address" required>
                              <input type="text" name="city" placeholder="City" required>
                              <input type="number" name="phone" placeholder="Phone Number" required>
                              <!-- Allow the customer to enter the desired quantity -->
         					  <input type="number" name="quantity" value="1" />
    						  <input type="text" name="item_name" value="Name of Item" />


                              
                           </div>
                           <div class="right-section-pay">
                               <label>Credit Card Support</label>
                                <div class="credit-images">
                                   <img src="image/americanExpress.gif" alt="americanExpress.gif">
                                   <img src="image/masterCard_en_IE.gif" alt="masterCard_en_IE.gif">
                                   <img src="image/visa_en_IE.gif" alt="visa_en_IE.gif">
                                </div>
                                <input type="number" name="card-number" placeholder="Credit Card Number" required>
                                    <label expiration-label>Expiration Date:</label>
                                <input type="date" name="expiration-date" >
                                <input type="text" name="card-code" placeholder="Card Security Code" required>
                           </div>
                           <div class="clear-float"></div>
                                <input type="submit" name="pay" value="Apply Credit">
                       </form>
               </div>
               
            <!-- end pay -->
      <!-- === start rate ========= -->
             <div class="all search rate">
                   <span class="close">X</span>
                  <h4>Please Share Your Rating Of Our Service:</h4>
                <form class="rate-form" action="index.php" method="post">
                    <table>
                      <tr>
                        <td><input type="radio" name="rate" value=""></td>
                        <td>Exelant</td>
                        <td><input type="radio" name="rate" value=""></td>
                        <td>Very Good</td>
                        <td><input type="radio" name="rate" value=""></td>
                        <td>Good</td>
                        <td><input type="radio" name="rate" value=""></td>
                        <td>Bad</td>
                      </tr>
                    </table>
                    <input type="submit" name="submit" value="Submit">
                </form>
             </div>
            <!-- end rate -->
          <!-- ======= start complane ======= -->
               <div class="all search complane">
                         <span class="close">X</span>
                      <h4>Write Your Complane:</h4>
                      <form name="form2" action="D:\prog\XAMPP\htdocs\PHPMailer-master\phpmailer.php" >
                     <textarea name="complane" placeholder="Write Your Complane"></textarea>
                     <button type="button" name="button">Send</button>
                     </form>
               </div>
          <!-- end complane -->
          <!-- =============== start update profile ====== -->
          <div class="all search update-profile">
              <span class="close">X</span>
            <form class="" action="index.php" method="post">
                 <table>
                   <tr>
                     <td>First Name:</td>
                     <td><input type="text" name="name" placeholder="First Name"></td>
                   </tr>
                   <tr>
                     <td>Last Name:</td>
                     <td><input type="text" name="name" placeholder="Last Name"></td>
                   </tr>
                   <tr>
                     <td>Password:</td>
                     <td><input type="password" name="password" placeholder="Enter Password"></td>
                   </tr>
                   <tr>
                     <td>Re Type Password:</td>
                     <td><input type="password" name="password" placeholder="Re Enter Password"></td>
                   </tr>
                   <tr>
                     <td>Gender:</td>
                     <td><input type="radio" name="Gender" value=""><label >Male</label><input type="radio" class="female" name="Gender" value=""><label>Female</label></td>
                   </tr>
                   <tr>
                     <td>Phone Number:</td>
                     <td><input type="text" name="number-phone" placeholder="Phone Number"></td>
                   </tr>
                 </table>
                <input type="submit" name="submit" value="Submit">
            </form>
          </div>
            <!-- end update profile -->
     </div>
  </main>
  <footer>
    <div class="container">
      <div class="left-footer">Copyright (c) 2017 All Rights Reserved To <span>FCI-H.</span></div>
       <div class="center-footer">
         <h4>Follow Us:</h4>
          <i class="fa fa-facebook" aria-hidden="true"></i>
          <i class="fa fa-google-plus" aria-hidden="true"></i>
          <i class="fa fa-twitter" aria-hidden="true"></i>
          <i class="fa fa-linkedin" aria-hidden="true"></i>
       </div>
      <div class="right-footer">Designed By <span>Citizen Service</span>  Team</div>
      <div class="clear-float"></div>
    </div>
  </footer>
  </body>
</html>
