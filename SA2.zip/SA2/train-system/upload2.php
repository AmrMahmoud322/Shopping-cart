<!DOCTYPE html>
<html>
<body>

<form action="uploader.php" method="post" enctype="multipart/form-data">
    Select File:  
    <input type="file" name="fileToUpload"/>
    <input type="submit" value="Upload Image" name="submit"/>
</form>

<body>
<html>