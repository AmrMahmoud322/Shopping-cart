<?php 

public $DB;

    function __construct() {

        $this->DB = new DbConnection();

    }

     public function add_new_payamnet(payment $payment){

            $data=array('ssn'=>$user->getSsn(),'fname'=>$user->getFname(),'lname'=>$user->getLname(),'email'=>$user->getEmail()
        ,'phone'=>$user->getPhone(),'password'=>$user->getPassword(),
            'country'=>$user->address->getCounrty(),'state'=>$user->address->getState(),'city'=>$user->address->getCity(),'postalcode'=>$user->address->getPostalcode(),'street'=>$user->address->getStreet()
        ,'year'=>$user->date->getYear(),'month'=>$user->date->getMonth(),'day'=>$user->date->getDay());






include 'passenger.php';
$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "software";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['address']) && isset($_POST['city']) &&
isset($_POST['phone']) && isset($_POST['quantity'])&& isset($_POST['item_name'])&& isset($_POST['card_number'])&& isset($_POST['expiration_date'])&& isset($_POST['card_code'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $phone = $_POST['phone'];
    $quantity = $_POST['quantity'];
    $item_name = $_POST['item_name'];
    $card_number = $_POST['card_number'];
    $expiration_date = $_POST['expiration_date'];
    $card_code = $_POST['card_code'];


$sql = "INSERT INTO payment (fname, lname, address,city, phone, quantity,item_name, card_number, expiration_date,card_code)
VALUES ($fname, $lname, $address,$city,$phone,$quantity,$item_name,$card_number,$expiration_date, $card_code)";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();


}
 ?>