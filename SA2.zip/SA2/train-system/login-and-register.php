<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>login and register</title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/home-page.css">
    <link rel="stylesheet" href="css/login.css">
  </head>
  <body>
      <header>
         <nav>
           <div class="container">
               <div class="logo">
                 <h2><span>Citizen</span> Service</h2>
               </div>
                 <form action="../Connectinghtml/login.php" method="post">
                   <input type="text" class="login" name="email" placeholder="User Name">
                   <input type="password" class="login" name="pass" placeholder="Password">
                      <input type="submit" class="submit" name="submit" value="Log in">
                     <br><br>
                     <span style="color: #f00;"><?php
                         session_start();
                         if(!empty($_SESSION['error_login']))
                             echo $_SESSION['error_login'];

                         session_destroy();
                         ?></span>
                </form>

           </div>
           <div class="clear-float"></div>
         </nav>
         <!-- line -->
            <div class="line">
               <div class="head-line">Register</div>
           </div>
              <!-- register -->
           <div class="register">
             <div class="container">
                  <h2>Creat New Acount</h2>
                <form class="" action="../Connectinghtml/register.php" method="post" >
                   <input type="text" name="fname" placeholder="First Name" required>
                   <input type="text" name="lname" placeholder="Last Name" required>
                   <input type="email" name="email" placeholder="email" required>
                   <input type="text" name="phone" placeholder="Phone Number" required>
                   <input type="password" name="password" placeholder="Enter Password" required>
                   <input type="password" name="repassword" placeholder="Re Enter Password" required>
                   <input type="number" name="ssn" placeholder="SSN" required>
                   <input type="date" name="birthday" required>
                   <select name="option" required>
                      <option >- Select State -  </option>
                      <option value="cairo">Cairo </option>
                      <option value="alex">Alex </option>
                      <option value="asuit">Asuit </option>
                      <option value="souhag">Souhag </option>
                      <option value="aswan">Aswan </option>
                      <option value="tanta">Tanta </option>
                   </select>
                   <input type="text" name="city" value="" placeholder="your City" required>
                   <input type="number" name="postalcode" value="" placeholder="Postal Code" required>
                   <input type="text" name="street" value="" placeholder="Street" required>
                   <input type="submit" class="submit" name="submit" value="Submit">
                    <span style="color: #f00;"><?php

                        if(!empty($_SESSION['error']))
                            echo $_SESSION['error'];


                        ?></span>
                </form>

             </div>
           </div>
      </header>
      <br><br><br>
      <footer>
        <div class="container">
          <div class="left-footer">Copyright (c) 2017 All Rights Reserved To <span>FCI-H.</span></div>
           <div class="center-footer">
             <h4>Follow Us:</h4>
              <i class="fa fa-facebook" aria-hidden="true"></i>
              <i class="fa fa-google-plus" aria-hidden="true"></i>
              <i class="fa fa-twitter" aria-hidden="true"></i>
              <i class="fa fa-linkedin" aria-hidden="true"></i>
           </div>
          <div class="right-footer">Designed By <span>Citizen Service</span>  Team</div>
          <div class="clear-float"></div>
        </div>
      </footer>
  </body>
</html>
