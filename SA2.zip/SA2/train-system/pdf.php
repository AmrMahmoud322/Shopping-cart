<?php
require('../fpdf/fpdf.php');

class PDF extends FPDF
{
function Header()
{
	global $title;
	$this->Image('etr.jpg',10,6,50,0,'','passenger.php');

	// Arial bold 15
	$this->SetFont('Arial','B',15);
	// Calculate width of title and position
	$w = $this->GetStringWidth($title)+6;
	$this->SetX((210-$w)/2);
	// Colors of frame, background and text
	$this->SetDrawColor(0,80,180);
	$this->SetFillColor(240,248,255);
	$this->SetTextColor(0,0,0);
	// Thickness of frame (1 mm)
	$this->SetLineWidth(1);
	// Title
	$this->Cell($w,9,$title,1,1,'C',true);
	// Line break
	$this->Ln(24);
}

function Footer()
{
	// Position at 1.5 cm from bottom
	$this->SetY(-15);
	// Arial italic 8
	$this->SetFont('Arial','I',8);
	// Text color in gray
	$this->SetTextColor(128);
	// Page number
	$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
	$this->Cell(-190,20,'adsfsfd ',0,0,'C');
	
}

function ticket_Body($file)
{
	// Read text file
	$txt = file_get_contents($file);
	$this->SetFont('Times','',15);
	// Output justified text
	$this->MultiCell(0,5,$txt);
	// Line break
	$this->Ln();
}

function Print_ticket( $file)
{
	$this->AddPage();
	$this->ticket_Body($file);
}
}

$pdf = new PDF();
$title = 'passenger ticket';
$pdf->SetTitle($title);
$pdf->Print_ticket('ticket.txt');
$pdf->Output();
?>
