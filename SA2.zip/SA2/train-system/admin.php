<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Admin Page</title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/login.css" >
    <link rel="stylesheet" href="css/home-page.css">
    <link rel="stylesheet" href="css/admin.css">
  </head>
  <body>
  <?php session_start(); ?>
   <script src="js/jquery-1.11.3.min.js"></script>
   <script src="js/click.js"></script>
    <header>
       <nav>
         <div class="container">
             <div class="logo">
               <h2><span>Citizen</span> Service</h2>
             </div>
                <h1>Welcome Admin :)</h1>
         </div>
       </nav>
    </header>
    <!-- main -->
    <main>
       <section class="jobs">
          <div class="container">
            <h2>What Do You Want To Do</h2>
               <a href="#" class="a-add-train">Add Train</a>
               <a href="#" class="a-remove-train">Remove Train</a>
               <a href="#" class="a-view-removed-train">View Removed Train</a>
               <a href="#" class="a-search-for-users">Search For Users</a>
               <a href="#" class="a-add-clerk">Add Clerk</a>
               <a href="#" class="a-add-admin">Add admin</a>
               <a href="#" class="a-view-reserved-ticket">View Reserved Ticket</a>
               <a href="#" class="a-view-canceled-ticket">View Canceld Ticket</a>
               <a href="#" class="a-check-train">Check Train</a>
               <a href="#" class="a-delete-user">Delete User</a>
               <!-- ==== add train =========== -->
               <header>
               <div class="container">
                 <div class="search add-train">
                   <span class="close">X</span>
                   <div class="inputs">
                     <form class="" action="../Connectinghtml/addTrain.php " method="post">
                     <!-- leaving from      -->
                       <div class="leaving-from">
                         <label>Leaving From:</label>
                         <select name="from"required>
                            <option >- Select City -  </option>
                            <option value="cairo">Cairo </option>
                            <option value="alex">Alex </option>
                            <option value="asiut">Asuit </option>
                            <option value="souhag">Souhag </option>
                            <option value="aswan">Aswan </option>
                            <option value="tanta">Tanta </option>
                         </select>
                       </div>
                       <!-- going to -->
                       <div class="leaving-from">
                         <label>Going To:</label>
                         <select name="to" required>
                            <option >- Select City -  </option>
                            <option value="cairo">Cairo </option>
                            <option value="alex">Alex </option>
                            <option value="asuit">Asuit </option>
                            <option value="souhag">Souhag </option>
                            <option value="aswan">Aswan </option>
                            <option value="tanta">Tanta </option>
                         </select>
                       </div>
                       <label>Date:</label>
                       <input type="date" class="date" name="date" value="">
                       <!-- time -->
                       <div class="leaving-from time" >
                         <label >Time:</label>
                         Hours:<input type="number" name="hour" min="0" max="24"><br>
                         Minutes:<input type="number" name="minute" min="0" max="60"><br>

                       </div>
                       <input type="submit" class="submit" name="search" value="Add">
                       </form>
                       <span style="color: #f00;">
                <?php

                if(!empty($_SESSION['addtrain']))
                    echo $_SESSION['addtrain'];
                ?>
                </span>
                   </div>
                 </div>

               </div>


               </header>
               <!-- ====== remove train === -->
               <header>
               <div class="container">
                 <div class="search remove-train">
                   <span class="close">X</span>
                   <div class="inputs">
                    <form action="../deletetrains.php"  method="POST">
                       <input type="text" name="search">
                        <input type="submit" name="submit" value="Search">
                        <span style="color: #f00;" >
                        <?php
                            if(!empty($_SESSION['removetrain']))
                                echo $_SESSION['removetrain'];
                        ?>
                        </span>
                           </form>

                   </div>
                 </div>
               </div>
               </header>
               <!-- ======== view removed train ======= -->
               <div class="search check-train view-removed-train">
                 <span class="close">X</span>
                  <h2>Removed Train</h2>
                   <form action="../Connectinghtml/view_removed.php" method="post">
                       <input type="submit" value="view" name="view">
                   </form>
               </div>
               <!-- ============ -->
              <!-- ===== search for users ======= -->
              <div class="search search-for-users">
                <span class="close">X</span>
                  <form action="../searchusers.php"  method="POST">
                       <input type="text" name="search">
                        <input type="submit" name="submit" value="Search">
                  </form>
                  <span style="color: #F00;">
                          <?php
                            //session_start();
                          if(!empty($_SESSION['searcherror']))
                              echo $_SESSION['searcherror'];
                          ?>

                      </span>
              </div>
              <!-- ======== -->
              <!-- ==== add clerk ==== -->
              <div class="search add-clerk">
                <span class="close">X</span>
                  <div class="register">
                    <div class="container">
                       <form class="" action="../Connectinghtml/add_clerk.php" method="post" >
                          <input type="text" name="c_fname" placeholder="First Name" required>
                          <input type="text" name="c_lname" placeholder="Last Name" required>
                          <input type="email" name="c_email" placeholder="email" required>
                          <input type="text" name="c_phone" placeholder="Phone Number" required>
                          <input type="password" name="c_password" placeholder="Enter Password" required>
                          <input type="password" name="c_repassword" placeholder="Re Enter Password" required>
                          <input type="number" name="c_salary" placeholder="Salary" required>
                          <input type="submit" class="submit" name="submit" value="Add">
                       </form>
                    </div>
                  </div>
              </div>
              <!-- ======== -->
              <!-- add admin -->
              <div class="search add-admin">
                <span class="close">X</span>
                  <div class="register">
                    <div class="container">
                       <form class="" action="../Connectinghtml/add_admin.php" method="post" >
                          <input type="text" name="fname" placeholder="First Name" required>
                          <input type="text" name="lname" placeholder="Last Name" required>
                          <input type="email" name="email" placeholder="email" required>
                          <input type="text" name="phone" placeholder="Phone Number" required>
                          <input type="password" name="password" placeholder="Enter Password" required>
                          <input type="password" name="repassword" placeholder="Re Enter Password" required>
                          <input type="number" name="salary" placeholder="Salary" required>
                          <input type="submit" class="submit" name="submit" value="Add">
                       </form>
                    </div>
                  </div>
              </div>
              <!-- ======= -->
              <!-- view reserved tickets -->
              <div id="view-reserved-ticket" class="search view-reserved-ticket">
                <span class="close">X</span>
                  <h3>  Reserved Tickets: </h3>
                  <form action="../Connectinghtml/viewreservedtickets.php">
                  <input type="submit" value="view" name="view">
                  </form>
              </div>
              <!-- ================= -->
              <!-- ======== view canceled ticket ======= -->
              <div class="search view-reserved-ticket view-canceled-ticket">
                <span class="close">X</span>
                  <h3>  Canceled Tickets: </h3>
                  <form action="../Connectinghtml/viewcanceledtickets.php">
                      <input type="submit" value="view" name="view">
                  </form>
              </div>
              <!-- ============ -->
              <!-- ======== check train ===== -->
                 <div id="check-train" class="search check-train">
                   <span class="close">X</span>
                      <div class="">
                        <input type="text" name="check-train" placeholder="Enter Train's ID ">
                        <button type="button" class="b-train-details" name="button">Check</button>
                        <form action="../search.php"  method="POST">
                       <input type="text" name="search">
                        <input type="submit" name="submit" value="Search">
                  </form>
                      </div>
                 </div>

              <!-- ===== -->
              <!-- ==== delete user ==== -->
              <div class="search delete-user">
                <span class="close">X</span>
                   <form action="../delete.php"  method="POST">
                       <input type="text" name="search">
                        <input type="submit" name="submit" value="Search">
                           </form>
              </div>
              <!-- ====== -->
              <!-- ==== view-massage-and-reply ==== -->
           </div>
       </section>
    </main>
    <footer>
      <div class="container">
        <div class="left-footer">Copyright (c) 2017 All Rights Reserved To <span>FCI-H.</span></div>
         <div class="center-footer">
           <h4>Follow Us:</h4>
            <i class="fa fa-facebook" aria-hidden="true"></i>
            <i class="fa fa-google-plus" aria-hidden="true"></i>
            <i class="fa fa-twitter" aria-hidden="true"></i>
            <i class="fa fa-linkedin" aria-hidden="true"></i>
         </div>
        <div class="right-footer">Designed By <span>Citizen Service</span>  Team</div>
        <div class="clear-float"></div>
      </div>
    </footer>
  </body>
</html>
