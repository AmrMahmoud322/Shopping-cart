<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "software";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$valueToSearch = $_POST['valueToSearch'];

$sql = "SELECT * FROM customers WHERE f_name=$valueToSearch ";
$result = mysqli_query($sql, $connection);


if ($result)
 {
  while($row = mysqli_fetch_array($result))
 {

?>


<table>
<tr><th>ID</th><th>First Name</th><th>Last Name</th></tr>
<tr>
<td><?php echo $row["f_name"]; ?></td>
<td><?php echo $row["l_name"]; ?></td>
</tr>

<?php
 }
} 
?>
</table>