<?php
include_once '../Database/Admin_Queries.php';
include_once '../soft/User.php';
$admin = new Admin_Queries();
$usr = new User();
if(isset($_POST['fname']) &&
isset($_POST['lname']) &&
isset($_POST['email']) &&
isset($_POST['phone']) &&
isset($_POST['password']) &&
isset($_POST['repassword']) &&
isset($_POST['option']) &&
isset($_POST['city']) &&
isset($_POST['postalcode']) &&
isset($_POST['street']) &&
isset($_POST['birthday'])
){
// $fname =mysqli_real_escape_string($_POST['fname']);
// $lname =mysqli_real_escape_string($_POST['lname']);
// $email =mysqli_real_escape_string($_POST['email']);
// $phone =mysqli_real_escape_string($_POST['phone']);
// $password =mysqli_real_escape_string($_POST['password']);
// $repassword =mysqli_real_escape_string($_POST['repassword']);

// $ssn =mysqli_real_escape_string($_POST['ssn']);
// $state =mysqli_real_escape_string($_POST['option']);
// $city =mysqli_real_escape_string($_POST['city']);
// $postalcode =mysqli_real_escape_string($_POST['postalcode']);
// $street =mysqli_real_escape_string($_POST['street']);
$date =explode('-',$_POST['birthday']);

$fname =$_POST['fname'];
$lname =$_POST['lname'];
$email =$_POST['email'];
$phone =$_POST['phone'];
$password =$_POST['password'];
$repassword =$_POST['repassword'];

$ssn =$_POST['ssn'];
$state =$_POST['option'];
$city =$_POST['city'];
$postalcode =$_POST['postalcode'];
$street =$_POST['street'];

    // if(!empty($fname) && !empty($lname) &&!empty($email) &&!empty($phone) &&!empty($password) &&
    //     !empty($repassword) && !empty($ssn) && !empty($state) && !empty($city) &&
    //     !empty($postalcode) && !empty($street)
    // ){
        if($password == $repassword){
    $usr->setFname($fname);$usr->setLname($lname);$usr->setPhone($phone);$usr->setEmail($email);$usr->setPassword($password);
    $usr->setSsn($ssn);$usr->date->getYear($date[0]);$usr->date->getMonth($date[1]);$usr->date->setDay($date[2]);
    $usr->address->setCounrty("Egypt");$usr->address->getCity($city);$usr->address->setState($state);
    $usr->address->getPostalcode($postalcode);$usr->address->getStreet($street);

    if ($admin->add_new_user($usr)){

        header('location: ../train-system/passenger.php');
    }else{
        session_start();
        $_SESSION['error'] = "cann't submit email aleardy exits";
        header('location: ../train-system/login-and-register.php');

    }
    }else{
            session_start();
            $_SESSION['error'] = "password doesn't match";
            header('location: ../train-system/login-and-register.php');
        }
    // }else{
    //     session_start();
    //     $_SESSION['error'] = "fields cannot be empty";
    //     header('location: ../train-system/login-and-register.php');
    // }
}
?>