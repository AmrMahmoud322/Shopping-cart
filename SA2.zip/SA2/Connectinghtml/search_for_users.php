<?php
 						
 	include_once'../soft/Admin.php';
  if(isset($_POST['search_i']) && isset($_POST['search_e'])){

        $s_id = $_POST['id'];
      $s_email = $_POST['email'];
      if(!empty($s_id) && !empty($s_email)){
         $admin = new Admin();
      if($data = $admin->search_for_passenger_info($s_email,null)){

      header('location: ../train-system/admin.php');
     }else{
          session_start();
          $_SESSION['searcherror'] = "user doesn't exist";
          header('location: ../train-system/admin.php');
      }
         }  else{
          session_start();
          $_SESSION['searcherror'] = "fields cann't be empty";
          header('location: ../train-system/admin.php');
      }
         }

                   ?>