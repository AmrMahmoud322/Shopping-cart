<?php
include "../Database/Admin_Queries.php";
$date = explode('-',date('y-m-d'));
$year = 2000+$date[0];
$user = new Admin_Queries();
if(isset($_POST['view'])){
    if($date = $user->view_reserved_tickets($year,$date[1],$date[2])){

        header('location: ../train-system/admin.php');

    }else{

        header('location: ../train-system/admin.php');

    }
}