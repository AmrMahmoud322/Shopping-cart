$(document).ready(function() {
  //===========main page
  $("#search-for-trains").click(function () {
    $(".trains-details").show();
  })
// ======= admin page ====
  // close
  $(".close").click(function() {
    $(".search , .view").hide();
    $(".trains-details").hide();
    $("a").css("background","#29abe2");
  })
  // add train
  $(".a-add-train").click(function () {
    $(".search").hide();
    $(".add-train").toggle();
    $("a").css("background","#29abe2");
    $(this).css("background","#2D6CDF");
  })
  // remove train
  $(".a-remove-train").click(function () {
    $(".search").hide();
    $(".remove-train").toggle();
    $("a").css("background","#29abe2");
    $(this).css("background","#2D6CDF");
  })
// view-removed-train
  $(".a-view-removed-train").click(function () {
    $(".search").hide();
    $(".view-removed-train").toggle();
    $("a").css("background","#29abe2");
    $(this).css("background","#2D6CDF");
  })
// search search-for-users
  $(".a-search-for-users").click(function () {
    $(".search").hide();
    $(".search-for-users").toggle();
    $("a").css("background","#29abe2");
    $(this).css("background","#2D6CDF");
  })
// add clerk
  $(".a-add-clerk").click(function () {
    $(".search").hide();
    $(".add-clerk").toggle();
    $("a").css("background","#29abe2");
    $(this).css("background","#2D6CDF");
  })
// add admin
$(".a-add-admin").click(function () {
  $(".search").hide();
  $(".add-admin").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
// view-reserved-ticket
$(".a-view-reserved-ticket").click(function () {
  $(".search").hide();
  // $(".view-reserved-ticket").toggle();
  $("#view-reserved-ticket").toggle();

  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
// view-canceled-ticket
$(".a-view-canceled-ticket").click(function () {
  $(".search").hide();
  $(".view-canceled-ticket").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
//Check train
$(".a-check-train").click(function () {
  $(".search").hide();
  $("#check-train").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
$(".b-train-details").click(function() {
   $(".train-details").toggle();
})
// delete-user
$(".a-delete-user").click(function () {
  $(".search").hide();
  $(".delete-user").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
// view-massage-and-reply
$(".a-view-massage-and-reply").click(function () {
  $(".search").hide();
  $(".view-massage-and-reply").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
// ============== Financial Manager ======
//view salary
$(".a-view-salaries").click(function() {
  $(".view").hide();
  $(".view-salaries").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
//view report
$(".a-view-report").click(function() {
  $(".view").hide();
  $(".view-report").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
// ====== clerk page ====
$("#check-ticket").click(function() {
  $(".ticket-details").show();
})
// ===== passenger page -====
 // search
 $(".a-search").click(function() {
   $(".all").hide();
   $(".search-about-trains").toggle();
   $("a").css("background","#29abe2");
   $(this).css("background","#2D6CDF");
 })
 // view-time-table
 $(".a-view-time-table").click(function() {
   $(".all").hide();
   $(".view-time-table").toggle();
   $("a").css("background","#29abe2");
   $(this).css("background","#2D6CDF");
 })
 // update ticket
 $(".a-update-ticket").click(function() {
   $(".all").hide();
   $(".update-ticket").toggle();
   $("a").css("background","#29abe2");
   $(this).css("background","#2D6CDF");
 })
        // find-ticket-buttom in update-ticket
 $("#find-ticket-buttom").click(function() {
   $(".update-ticket .update-ticket-options").show();
 })

 //cancel ticket
 $(".a-cancel-ticket").click(function() {
   $(".all").hide();
   $(".cancel-ticket").toggle();
   $("a").css("background","#29abe2");
   $(this).css("background","#2D6CDF");
 })
// Rate
$(".a-rate").click(function() {
  $(".all").hide();
  $(".rate").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
// pay
$(".a-pay").click(function() {
  $(".all").hide();
  $(".pay").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
// complane
$(".a-complane").click(function() {
  $(".all").hide();
  $(".complane").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
// update-profile
$(".a-update-profile").click(function() {
  $(".all").hide();
  $(".update-profile").toggle();
  $("a").css("background","#29abe2");
  $(this).css("background","#2D6CDF");
})
});
