<?php
include_once '../Database/User_Queries.php';
if(isset($_POST['tnum'])){
    $tnum = $_POST['tnum'];

$user = new User_Queries();
if(!empty($tnum)){
if($user->cancel_ticket(null,$tnum)){
    session_start();
    $_SESSION['cancelticket'] ="ticket canceled successfully";
    header('location: ../train-system/passenger.php');
}else{
    session_start();
    $_SESSION['cancelticket'] ="ticket doesn't exist";
    header('location: ../train-system/passenger.php');
}
}else{
    session_start();
    $_SESSION['cancelticket'] ="field cann'ot be empty";
    header('location: ../train-system/passenger.php');

}
}