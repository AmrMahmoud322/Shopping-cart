<?php
include_once '../Database/Admin_Queries.php';
echo "khfhg";
$date = explode('-',date('y-m-d'));
$year = 2000+$date[0];
if(isset($_POST['view'])){
    $admin = new Admin_Queries();
    if($date = $admin->view_canceled_tickets($year,$date[1],$date[2])){
        header('location: ../train-system/admin.php');

    }else{
        header('location: ../train-system/admin.php');
    }
}