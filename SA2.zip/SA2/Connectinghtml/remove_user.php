<?php
 						
 	include_once'../soft/Admin.php';
    if(isset($_POST['id']) || isset($_POST['email'])){
        $d_iduser = $_POST['id'];$emailuser = $_POST['email'];
        $admin = new Admin();
        echo 'ay 7aga';
        if($data = $admin->remove_passenger($emailuser)) {
            header('location: ../train-system/admin.php');
        }else{
            header('location: ../train-system/admin.php');
        }
    }

                   ?>