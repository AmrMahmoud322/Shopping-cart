<?php
include "../Database/User_Queries.php";
$date = explode('-',date('y-m-d'));
$year = 2000+$date[0];
$user = new User_Queries();
if(isset($_POST['view'])){
if($date = $user->view_removed_train(null,null,$year,$date[1],$date[2])){
    header('location: ../train-system/admin.php');
}else{
    header('location: ../train-system/admin.php');
}
}