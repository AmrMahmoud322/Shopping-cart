<?php
include_once '../soft/payment.php';

if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['address']) && isset($_POST['city']) &&
isset($_POST['phone']) && isset($_POST['quantity'])&& isset($_POST['item_name'])&& isset($_POST['card_number']) && isset($_POST['expiration_date'])&& isset($_POST['card_code'])) {
    $d_fname = $_POST['fname'];
    $d_lname = $_POST['lname'];
    $d_address = $_POST['address'];
    $d_city = $_POST['city'];
    $d_phone = $_POST['phone'];
    $d_quantity = $_POST['quantity'];
    $d_item_name = $_POST['item_name'];
    $d_card_number = $_POST['card_number'];
    $d_expiration_date = $_POST['expiration_date'];
    $d_card_code = $_POST['card_code'];


    $payment = new payment();

    $payment->setFname($d_fname);
    $payment->setLname($d_lname);
    $payment->setAddress($d_address);
    $payment->setCity($d_city);
    $payment->setPhone($d_phone);
    $payment->setQuantity($d_quantity);
    $payment->setItem_name($d_item_name);
    $payment->setCard_number($d_card_number);
    $payment->setExpiration_date($d_expiration_date);
    $payment->setCard_code($d_card_code);

    if($payment->add_payment($payment)){
        header('location: ../train-system/passenger.php');
    }else{
        header('location: ../train-system/passenger.php');
    }
}


                       ?>