<?php
include_once '../soft/Admin.php';
if(isset($_POST['tnum'])){
    $tnum = mysqli_real_escape_string($_POST['tnum']);
    $admin = new Admin();

    if(!empty($tnum)){
    if($test = $admin->remove_train($tnum)){
        session_start();
        $_SESSION['removetrain'] ="train canceled successfully";
       header('location: ../train-system/admin.php');
    }else{
        session_start();
        $_SESSION['removetrain'] ="cann't remove the train may be it doesn't exist";
        header('location: ../train-system/admin.php');

    }
    }else{
        session_start();
        $_SESSION['removetrain'] ="field can't be empty";
        header('location: ../train-system/admin.php');
    }
}