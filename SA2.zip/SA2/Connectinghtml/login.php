<?php
include_once '../soft/User.php';
include_once '../soft/Admin.php';
if(isset($_POST['email']) && isset($_POST['pass'])){
    $email = mysqli_real_escape_string($_POST['email']);$pass = mysqli_real_escape_string($_POST['pass']);
    if(!empty($email) && !empty($_POST)){
        $usr = new User();
        $admin = new Admin();
        if($usr->logIn($email,$pass))
            header('location: ../train-system/passenger.php');
        else if($admin->logIn($email,$pass))
            header('location: ../train-system/admin.php');
        else{
            session_start();
            $_SESSION['error_login'] = "wrong Password or email";
            header('location: ../train-system/login-and-register.php');
        }
    }else{
        session_start();
        $_SESSION['error_login'] = "fields cannot be empty";
        header('location: ../train-system/login-and-register.php');
    }
}
?>