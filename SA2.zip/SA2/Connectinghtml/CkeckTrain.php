<?php
include_once '../soft/Admin.php';
if($_POST['check-train']){
    $check = mysqli_real_escape_string($_POST['check-train']);
    if(!empty($check)){
        $admin = new Admin();
        if($admin->check_train_info($check)){
        header("location: ../train-system/admin.php");
        }else{
            session_start();
            $_SESSION['checktrain'] = "train doesn't exist";
            header("location: ../train-system/admin.php");
        }
    }else {
        session_start();
        $_SESSION['checktrain'] = "fields cannot be empty";
        header("location: ../train-system/admin.php");
    }
}