<?php
include '../Database/Admin_Queries.php';

$echoed;
if(isset($_POST['from']) && isset($_POST['to']) && isset($_POST['date']) && isset($_POST['hour']) && isset($_POST['minute'])){
    $from = $_POST['from'];$to = $_POST['to'];$date = explode('-',$_POST['date']);
    $hours= $_POST['hour'];$minutes = $_POST['minute'];
    if(!empty($from)&& !empty($to) && !empty($date) && !empty($hours) && !empty($minutes)) {
        $admin = new Admin_Queries();
        $train = new Train();
        $current = explode('-', date('y-m-d'));
        $train->setSource($from);
        $train->setDestination($to);
        $train->moving_date->setYear($date[0]);
        $train->moving_date->getMonth($date[1]);
        $train->moving_date->setDay($date[2]);
        $train->moving_time->getHour($hours);
        $train->moving_time->setMinute($hours);
        $train->moving_time->setSecond(0);
        if (($hours <= 24 && $hours >= 0) && ($minutes <= 60 && $minutes >= 0) &&
            ($date[0] == 2018 && $date[1] == 5 && $date[2] >= $current[2])) {
            if ($admin->add_new_train($train)) {
                session_start();
                $_SESSION['addtrain'] = "train added sucessfully";
                header("location: ../train-system/admin.php");

            } else {
                session_start();
                $_SESSION['addtrain'] = "cann't  add this train";
                header("location: ../train-system/admin.php");

            }
        }else{
            session_start();
            $_SESSION['addtrain'] = "there's something wrong with the date or the the time or both";
            header("location: ../train-system/admin.php");
        }
    } else {
            session_start();
            $_SESSION['addtrain'] = "fields cannot be empty!!";
            header("location: ../train-system/admin.php");
        }

}
?>