<?php
include_once '../soft/Admin.php';

if(isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['email']) && isset($_POST['phone']) &&
isset($_POST['password']) && isset($_POST['repassword'])&& isset($_POST['salary'])) {
    $d_fname = $_POST['fname'];
    $d_lname = $_POST['lname'];
    $d_email = $_POST['email'];
    $d_phone = $_POST['phone'];
    $d_password = $_POST['password'];
    $d_rpassword = $_POST['repassword'];
    $d_salary = $_POST['salary'];

    $admin = new Admin();

    $admin->setFname($d_fname);
    $admin->setLname($d_lname);
    $admin->setEmail($d_email);
    $admin->setPhone($d_phone);
    $admin->setPassword($d_password);
    $admin->setSalary($d_salary);

    if($admin->add_admin($admin)){
        header('location: ../train-system/admin.php');
    }else{
        header('location: ../train-system/admin.php');
    }
}


                       ?>