<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <title>Admin Page</title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/login.css" >
    <link rel="stylesheet" href="css/home-page.css">
    <link rel="stylesheet" href="css/admin.css">
<style>
table {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

 td,  th {
    border: 1px solid #ddd;
    padding: 8px;
}

 tr:nth-child(even){background-color: #f2f2f2;}

 tr:hover {background-color: #ddd;}

 th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>
</head>
<body>
<?php session_start(); ?>
   <script src="js/jquery-1.11.3.min.js"></script>
   <script src="js/click.js"></script>
    <header>
       <nav>
         <div class="container">
             <div class="logo">
               <h2><span>Citizen</span> Service</h2>
             </div>
                <h1>Welcome Admin :)</h1>
         </div>
       </nav>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "software";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT source, destination,year,month,day FROM trains";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>ID</th><th>tnum</th><th>tname</th><th>source</th><th>destination</th><th>steps_num</th><th>year</th><th>month</th><th>day</th><th>hour</th><th>minute</th><th>second</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>". $row["id"]."</td><td>". $row["tnum"]."</td><td>". $row["tname"]."</td><td>". $row["source"]."</td><td>". $row["destination"]."</td><td>".$row["steps_num"]."</td><td>".$row["year"]."</td><td>".$row["month"]."</td><td>".$row["day"]."</td><td>".$row["hour"]."</td><td>".$row["minute"]."</td><td>".$row["second"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
//$sql = "SELECT * FROM Orders LIMIT 30"; 

$conn->close();
?>
<footer>
      <div class="container">
        <div class="left-footer">Copyright (c) 2017 All Rights Reserved To <span>FCI-H.</span></div>
         <div class="center-footer">
           <h4>Follow Us:</h4>
            <i class="fa fa-facebook" aria-hidden="true"></i>
            <i class="fa fa-google-plus" aria-hidden="true"></i>
            <i class="fa fa-twitter" aria-hidden="true"></i>
            <i class="fa fa-linkedin" aria-hidden="true"></i>
         </div>
        <div class="right-footer">Designed By <span>Citizen Service</span>  Team</div>
        <div class="clear-float"></div>
      </div>
    </footer>

 

<link href="css/teamsidea.css" rel="stylesheet">

<h1><span class="blue">&lt;</span>Show<span class="blue">&gt;</span> <span 

class="yellow">Details</span></h1>


<table class="container">
    <thead>
        <tr>
            <th>
                <h1>Id</h1>
           </th>

            

            <th>
            <h1</h1>
            </th>

            <th>
                <h1></h1>
            </th>

            <th> 
                <h1> </h1>
            </th>

        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
              
            </td>
            <td>9518</td>
            <td>6369</td>
            <td>01:32:50</td>
        </tr>
        
    
    </tbody>
</table>


<div style="margin-left:1000px;">
</div>

</body>



