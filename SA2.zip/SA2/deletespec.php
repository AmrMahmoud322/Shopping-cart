<?php  
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "software";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
$name = $_POST['name'];
$query = "delete from cutomers where fname = '".$name."'";
if(mysqli_query($query)){
echo "deleted";}
else{
echo "fail";}