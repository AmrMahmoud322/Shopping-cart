 <!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
}
</style>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "software";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT fname, lname FROM customers where fname='Mary'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>firstname</th><th>lastname</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" .$row["fname"]."</td><td>" . $row["lname"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
//$sql = "SELECT * FROM Orders LIMIT 30"; 

$conn->close();
?>

</body>
</html>