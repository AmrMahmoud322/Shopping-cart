<?php


class Database_class {
    //put your code here
    private $host_name = 'localhost';
    private $user_name = 'root';
    private $db_password = '123456';
    private $db_name = 'softwaredatebase';//hn3'yr 2sm l database
    private $db_connect;//hn3mlo 34an y7sl connect m3  l database f l constructor
    private $db_select;
    
    function __construct() {
        $this->db_connect = $this->database_connection($this->host_name,$this->user_name,$this->db_password);
        $this->db_select = $this->database_select($this->db_name);       
                
    }
    
    public function database_connection($host_name,$user_name,$db_password){
        if(mysqli_connect($host_name,$user_name,$db_password)){
            return true;
        }else{
            die('cannot connect to the database somethis is wrong 4aklk keda wallah 23lm d5lt 7aga 3\'lt');
        }
    }
    
    public function database_select($db_name){
        if(@mysqli_select_db($db_name)){
            return true;
        }else{
            die('m4 3arfeen n select l database 2sm l  database 3\'lt yad');
        }
    }
    
    public function database_query($the_query){
        $query_run = mysqli_query($the_query);
        return $query_run;
    }
    
    public function get_row($the_query){
        if(!strstr(strtoupper($the_query), 'LIMIT')){
            $the_query .='LIMIT 0,1';
        }
        
        if (!($result = $this->database_query($the_query))) {
            die("Database error: " . mysqli_error() . "<br> fe l  query: " . $the_query);
        }

        return mysqli_fetch_array($result);
    }
    
     public function database_all_array($database_result) {
        $array_return=array();
        while ($row = mysqli_fetch_array($database_result)) {
            $array_return[] = $row;
        }
        if(count($array_return)>0)
         return $array_return;
    }
    
     public function database_all_assoc($database_result) {

        while ($row = mysqli_fetch_assoc($database_result)) {
            $array_return[] = $row;
        }
        return $array_return;
    }
    /*
     * Hena b2a htrg3li 3dd l row elly 7sl feha action y3no mslm updata aw delte
     * we keda y3noi
     */
    public   function database_affected_rows($database_result) {

        return mysqli_affected_rows($database_result);
    }
    /*
     *hena b2a  htrg3lna 3dd l rows bta3 l query elly ana 3awzha
     */
    public   function database_num_rows($database_result) {

        return mysqli_num_rows($database_result);
    }
    
      //hena ; update general l2y 7d yn3i
    
    public function update($table, $data, $where='1'){
    $query="UPDATE `$table` SET ";

    foreach($data as $key=>$val){
        if(strtolower($val)=='null')
            $query.= "`$key` = NULL, ";
        elseif(strtolower($val)=='now()') 
            $query.= "`$key` = NOW(), ";
        else
            $query.= "`$key`='".$this->escape($val)."', ";
    }

    $query = rtrim($query, ', ') . ' WHERE '.$where.';';

    return $this->query($query);
    }
    
    //hena bardo l insert htb2a general htshl 3lena kter
    
    
    public function insert($table, $data){
    $query="INSERT INTO `$table` ";
    $v=''; $n='';

    foreach($data as $key=>$val){
        $n.="`$key`, ";
        if(strtolower($val)=='null') $v.="NULL, ";
        elseif(strtolower($val)=='now()') $v.="NOW(), ";
        else $v.= "'".$val."', ";
    }

    $query .= "(". rtrim($n, ', ') .") VALUES (". rtrim($v, ', ') .");";

    if($this->database_query($query)){
        return mysqli_insert_id();
    }
    else return false;
    
    }
    /*
     * l function de hnst5dmha fe kol l users
     */
     public function get_user_by_email_password($email,$password,$table){
   
        $query="SELECT * FROM `$table` WHERE username='$email' and password='$password'  ";
        $user_data=$this->DB->get_row($query);
        return $user_data;
    }
        
}