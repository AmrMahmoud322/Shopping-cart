<form action="deletespec.php" method="post">
Name:
<input name="name" type="text" />
<input name="Submit" type="submit" value="delete record" />
</form>