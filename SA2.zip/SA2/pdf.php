<?php
require(dirname(__FILE__) .'fpdf/fpdf.php');


$pdf = new FPDF();

$pdf ->AddPage();
$pdf ->SetFont('arial','B',30);
$pdf ->Cell(0,10,'welcome','B',1,'C',0,'google.com');

$pdf ->Ln();
$pdf ->SetTextColor(155,225,225);
$pdf ->image ('Desktop\Capture');
$pdf ->Cell(0,10,'222222','B',1,'C',0,'google.com');

$pdf ->AddPage();




$pdf ->Output();


?>