<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <title>passenger Page</title>
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/login.css" >
    <link rel="stylesheet" href="css/home-page.css">
    <link rel="stylesheet" href="css/admin.css">
<style>
table {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

 td,  th {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: center;
}

 tr:nth-child(even){background-color: #f2f2f2;}

 tr:hover {background-color: #ddd;}

 th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: center;
    background-color: #4CAF50;
    color: white;
}
</style>
</head>
<body>
<?php session_start(); ?>
   <script src="js/jquery-1.11.3.min.js"></script>
   <script src="js/click.js"></script>
    <header>
       <nav>
         <div class="container">
             <div class="logo">
               <h2><span>Citizen</span> Service</h2>
             </div>
                <h1>Welcome Admin :)</h1>
         </div>
       </nav>
</head>
<body>
<div>
<?php
$servername="localhost";
$username="root";
$password="";
$dbname="software";

/* @var $_POST type */
$search_value= $_POST["search"];

$con=new mysqli($servername,$username,$password,$dbname);
if($con->connect_error){
    echo 'Connection Faild: '.$con->connect_error;
    }else{
        $sql=" SELECT pfname,plname ,id,ssn,email,train_id ,source,destination,class,year,month,day,hour,minute,second,price from tickets where id like 
        '%$search_value%'";

        $res=$con->query($sql);

		if ($res->num_rows > 0){
       echo "<table><tr><th>pfname</th><th>plname</th><th>id</th><th>ssn</th><th>email</th><th>train_id</th><th>source</th><th>destination</th><th>class</th><th>year</th><th>month</th><th>day</th><th>hour</th><th>minute</th><th>second</th><th>price</th></tr>";
    // output data of each row
    	while($row = $res->fetch_assoc()) {
        echo "<tr><td>". $row["pfname"]."</td><td>". $row["plname"]."</td><td>". $row["id"]."</td><td>". $row["ssn"]."</td><td>". $row["email"]."</td><td>". $row["train_id"]."</td><td>". $row["source"]."</td><td>". $row["destination"]."</td><td>". $row["class"]."</td><td>". $row["year"]."</td><td>". $row["month"].$row["day"]."</td><td>".$row["hour"]."</td><td>".$row["minute"]."</td><td>".$row["second"]."</td><td>".$row["price"]."</td></tr>";
    }
    echo "</table>";





                   
    	}
        }
?>
</div>
<button type="submit" value="back" name="back" href="../train-system/admin.php">back </button>

</body>