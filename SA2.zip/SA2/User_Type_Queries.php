<?php
/**
 * Created by PhpStorm.
 * User: omarabdelaziz
 * Date: 23/04/17
 * Time: 08:55 م
 */


namespace Database;
include_once '../Database/DataBase_Class.php';

class User_Type_Queries
{
    private $DB;

    public function __construct(){
        $this->DB = new Database_class();
    }

    public function get_user_type_by_id($id){
        $Query="SELECT * FROM `user_type`  where id=$id";
        $type_data=$this->DB->get_row($Query);
        return $type_data;
    }
    public function get_user_type_urls($user_type){
        $Query="SELECT page_user_type.url FROM 'page_user_type' where  user_type_urls.user_type_id=$user_type ";
        $result=$this->DB->database_query($Query);
        $URLS=$this->DB->database_all_array($result);
        return $URLS;
    }
}