<?php

include_once '../Database/DbConnection.php';
include_once '../soft/payment.php';
class Payment_Queries{
    //put your code here
    public $DB;

    function __construct() {

        $this->DB = new DbConnection();

    }

    public function add_new_payment(payment $payment){
        $data=array('fname'=>$payment->getFname(),
            'lname'=>$payment->getLname(),
            'address'=>$payment->getAddress(),
            'city'=>$payment->getCity(),
            'phone'=>$payment->getPhone(),
            'quantity'=>$payment->getQuantity(),
            'item_name'=>$payment->getItem_name(),
            'card_number'=>$payment->getCard_number(),
            'expiration_date'=>$payment->getExpiration_date(),
            'card_code'=>$payment->getCard_code());
        $result= $this->DB->insert('payment', $data);
        if($result){
            return TRUE;
        }
       else {
            return FALSE;

       }
    }

    
    
}

