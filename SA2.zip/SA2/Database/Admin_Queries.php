<?php

include_once '../Database/DbConnection.php';
include_once '../soft/User.php';
include_once '../soft/Admin.php';
include_once '../soft/Train.php';
class Admin_Queries{
    //put your code here
    public $DB;

    function __construct() {

        $this->DB = new DbConnection();

    }

    public function add_new_user(User $user){
        $data=array('ssn'=>$user->getSsn(),'fname'=>$user->getFname(),'lname'=>$user->getLname(),'email'=>$user->getEmail()
        ,'phone'=>$user->getPhone(),'password'=>$user->getPassword(),
            'country'=>$user->address->getCounrty(),'state'=>$user->address->getState(),'city'=>$user->address->getCity(),'postalcode'=>$user->address->getPostalcode(),'street'=>$user->address->getStreet()
        ,'year'=>$user->date->getYear(),'month'=>$user->date->getMonth(),'day'=>$user->date->getDay());


        $result= $this->DB->insert('customers', $data);
        return $result;
        if($result){
            return TRUE;
        }
       else {
            return FALSE;

       }
    }
    public function add_new_admin(Admin $admin){
        $data=array('fname'=>$admin->getFname(),'lname'=>$admin->getLname(),'phone'=>$admin->getPhone(),'email'=>$admin->getEmail(),'password'=>$admin->getPassword(),'salary'=>$admin->getSalary());

        $result= $this->DB->insert('admin', $data);
        if($result){
            return TRUE;
        }
       else {
            return FALSE;

       }
    }

    public function add_new_train(Train $train){
        $tdata  = array('tnum'=>$train->getTrainNum(),'tname'=>$train->getTrainName(),'source'=>$train->getSource(),'destination'=>$train->getDestination(),'steps_num'=>$train->getNumOfSteps(),'year'=>$train->moving_date->getYear(),'month'=>$train->moving_date->getMonth(),'day'=>$train->moving_date->getDay(),'hour'=>$train->moving_time->getHour(),'minute'=>$train->moving_time->getMinute(),'second'=>$train->moving_time->getSecond());

        $result= $this->DB->insert('trains', $tdata);
        if($result)
            return TRUE;
       else
            return FALSE;

    }

    public function add_new_clerk(Clerk $clerk){
        $data=array('fname'=>$clerk->getFname(),'lname'=>$clerk->getLname(),'email'=>$clerk->getEmail(),'password'=>$clerk->getPassword(),'salary'=>$clerk->getSalary());
        $result= $this->DB->insert('clerks', $data);
        if($result){
            return TRUE;
        }
       else {
            return FALSE;

       }
    }
    public function get_user($tname,$email = null,$id = null){
       if($email == null && $id == null && $tname){
           echo "function got no arguments";
       }else if(($email!=null) && ($id == null)){

        $query="SELECT * FROM `$tname` where email='$email'";
        $user_data=$this->DB->get_row($query);
        return $user_data;
       }else if(($email ==null) && ($id != null)){
            $query="SELECT * FROM `$tname` where id='$id'";
        $user_data=$this->DB->get_row($query);
        return $user_data;
       }

    }
        public function get_train($tname,$tnum= null,$tid = null){
        if($tnum == null && $tid == null && $tname){

        }else if(($tnum!=null) && ($tid == null)){

            $query="SELECT * FROM `$tname` where tnum='$tnum'";
            $data=$this->DB->get_row($query);
            return $data;
        }else if(($tnum ==null) && ($tid != null)){
            $query="SELECT * FROM `$tname` where id='$tid'";
            $data=$this->DB->get_row($query);
            return $data;
        }
    }

    /*
     * hena l method de ht4el ay user swa2 kan passenger 2w clerk
     */
    public function remove_user($tname,$umail){
      $query = "DELETE * FROM '$tname' where email = '$umail'";
           $query_run = $this->DB->database_query($query);
           if($this->DB->database_query($query))
                return true;
            else {
              return false;
            }

            }
            /*
             * ana hena ma redt4 23ml general method l l remove 34an l semantics bta3 l code
             */
    public function remove_train($tid,$tnum){
       if($tid == null && $tnum == null){
            throw new Exception("Ma td5l rkm ltrain wla l id wla hwa 4o3'l ,msh tamam ");
        }else if($tid != null && $tnum == null) {
             $query = "DELETE * FROM 'trains' where email = '$tid'";
           $user_data=$this->DB->database_query($query);
            if($user_data)
                return true;
            else {
                return false;
            }
        }else{
             $query = "DELETE FROM 'trains' where email = '$tnum'";
            $query_run =$this->DB->database_query($query);
            if($query_run)
                return true;
            else {
                return false;
                }
        }
    }
    public function edit_clerk($fname,$lname,$email,$password,$salary,$id){
        $cdata=array('fname'=>$fname,'lname'=>$lname,'email'=>$email,'password'=>$password,'salary'=>$salary);
        $result  = $this->DB->update('clerks',$cdata,$id);
        if($result)
            return true;
        else
            return false;
    }
    public function edit_train($tnum,$tname,$source,$destination,$year,$month,$day,$hour,$minute,$second,$id){
        $tdata  = array('tnum'=>$tnum,'tname'=>$tname,'source'=>$source,'destination'=>$destination
        ,'year'=>$year,'month'=>$month,'day'=>$day,'hour'=>$hour,
        'minute'=>$minute,'second'=>$second
        );
        $result  = $this->DB->update('trains',$tdata,$id);

        if($result)
            return true;
        else
            return false;
    }

    public function view_reserved_tickets($year,$month,$day)
    {
        $query = "SELECT * FROM 'reservedtickets' WHERE  year = '$year' AND month = '$month' AND day = '$day'";
        $train_data = $this->DB->database_all_assoc($query);
        return $train_data;
    }
    public function view_canceled_tickets($year,$month,$day)
    {
        $query = "SELECT * FROM 'canceledtickets' WHERE  year = '$year' AND month = '$month' AND day = '$day'";
        $train_data = $this->DB->database_all_assoc($query);
        return $train_data;
    }
}


            ?>

