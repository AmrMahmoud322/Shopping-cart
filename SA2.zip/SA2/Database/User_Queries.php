<?php

include_once '../Database/DbConnection.php';
include_once '../Database/Admin_Queries.php';
class User_Queries{
    //put your code here
    private $DB;
    public $AQ;
    function __construct() {
        $this->DB = new DbConnection();
        $this->AQ = new Admin_Queries();
    }


   public function reserve_ticket($pfname,$plname,$pid,$pssn,$pemail,Ticket $ticket){
        $ticket = array('pfname'=>$pfname,'plname'=>$plname,'id'=>$pid,'ssn'=>$pssn,'email'=>$pemail,'train_id'=>$ticket->train->getTrainNum(),'train_name'=>$ticket->train->getTrainName()
            ,'source'=>$ticket->train->getSource(),'destination'=>$ticket->train->getDestination(),
            'class'=>$ticket->getTravelingClass()
        ,'year'=>$ticket->traveling_date->getYear(),'month'=>$ticket->traveling_date->getMonth(),'day'=>$ticket->traveling_date->setDay(),
            'hour'=>$ticket->traveling_time->getHour(),'minute'=>$ticket->traveling_time->getMinute(),'second'=>$ticket->traveling_time->getSecond(),'price'=>$ticket->getPrice());
        $result = $this->DB->insert('tickets',$ticket);
        if($result)
            return true;
        else
            return false;
   }


   public function view_train($source,$destination,$year,$month,$day){
       if($source == NULL  && $destination == NULL && $year == NULL && $month == NULL && $day == NULL)
           throw new Exception("D5l data ya 3'by");
       else if($source != NULL  && $destination == NULL && $year == NULL && $month == NULL && $day == NULL)
       {
           $query = "SELECT * FROM 'trains' WHERE source = '$source'";
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       }else if($source != NULL  && $destination != NULL && $year == NULL && $month == NULL && $day == NULL){
           $query = "SELECT * FROM 'trains' WHERE source = '$source' AND destination = '$destination'";
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       }else if($source != NULL  && $destination != NULL && $year != NULL && $month == NULL && $day == NULL){
            $query = "SELECT * FROM 'trains' WHERE source = '$source' AND destination = '$destination' AND year = '$year'";
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       }else if($source != NULL  && $destination != NULL && $year != NULL && $month != NULL && $day == NULL){
            $query = "SELECT * FROM 'trains' WHERE source = '$source' AND destination = '$destination' AND year = '$year' AND month = '$month'"; 
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       } else {
            $query = "SELECT * FROM 'trains' WHERE source = '$source' AND destination = '$destination' AND year = '$year' AND month = '$month' AND day = '$day'"; 
           $train_data = $this->DB->database_all_assoc($query);
           return $train_data;
       }
   }
    public function view_removed_train($source,$destination,$year,$month,$day)
    {
        if ($source == NULL && $destination == NULL && $year == NULL && $month == NULL && $day == NULL)
            throw new Exception("D5l data ya 3'by");
        else if ($source != NULL && $destination == NULL && $year == NULL && $month == NULL && $day == NULL) {
            $query = "SELECT * FROM 'removedtrains' WHERE source = '$source'";
            $train_data = $this->DB->database_all_assoc($query);
            return $train_data;
        } else if ($source != NULL && $destination != NULL && $year == NULL && $month == NULL && $day == NULL) {
            $query = "SELECT * FROM 'removedtrains' WHERE source = '$source' AND destination = '$destination'";
            $train_data = $this->DB->database_all_assoc($query);
            return $train_data;
        } else if ($source != NULL && $destination != NULL && $year != NULL && $month == NULL && $day == NULL) {
            $query = "SELECT * FROM 'removedtrains' WHERE source = '$source' AND destination = '$destination' AND year = '$year'";
            $train_data = $this->DB->database_all_assoc($query);
            return $train_data;
        } else if ($source != NULL && $destination != NULL && $year != NULL && $month != NULL && $day == NULL) {
            $query = "SELECT * FROM 'removedtrains' WHERE source = '$source' AND destination = '$destination' AND year = '$year' AND month = '$month'";
            $train_data = $this->DB->database_all_assoc($query);
            return $train_data;
        } else {
            $query = "SELECT * FROM 'removedtrains' WHERE source = '$source' AND destination = '$destination' AND year = '$year' AND month = '$month' AND day = '$day'";
            $train_data = $this->DB->database_all_assoc($query);
            return $train_data;
        }
    }
   public function view_ticket($tid){
       $query = "SELECT * FROM 'reservedticket' where id = '$tid'";
       $ticket_data=$this->DB->get_row($query);
        return $ticket_data;
   }
  /*
   * method cancel l tickt ht4el l tivket mn l trserved ticket
   */
   public function cancel_ticket($tid,$tnum){
     if($tid !=null && $tnum == null){
         $query = "DELETE FROM 'ticket' WHERE tid = '$tid'";
     $query_run = mysqli_run($query);
     if($query_run)
         return true;
     }else if($tid ==null && $tnum != null){
         $query = "DELETE FROM 'ticket' WHERE tnum = '$tid'";
         $query_run = mysqli_query($query);
         if($query_run)
             return true;
     }

   }
   /*
    * 3ndna b2a l method de l httl3 kol l train 3la 7asab l date  
    */
   public function get_train_date($year,$month,$day){
       $query = "SELECT * FROM 'trains' WHERE year = '$year' AND month = '$month' AND day = '$day'";
       $train_data = $this->DB->get_row($query);
       return $train_data;
   }

   public function edit_user($ssn, $fname, $lname, $email, $phone, $password,$id){
       $udata = array('ssn'=>$ssn,'fname'=>$fname,'lname'=>$lname,'email'=>$email,'phone'=>$phone,'password'=>$password);
       $result = $this->DB->update('customers',$udata,$id);
       if($result)
           return true;
       else
           return false;
   }

    public function get_ticket($tid,$tnum){

         if(($tid!=null) && ($tnum == null)){

            $query="SELECT * FROM 'ticket' where tid ='$tid'";
            $data=$this->DB->get_row($query);
            return $data;
        }else if(($tid ==null) && ($tnum != null)){
            $query="SELECT * FROM 'tickets' where tnum = '$tnum'";
            $data=$this->DB->get_row($query);
            return $data;
        }

    }
    public function remove_ticket($tid,$tnum){
        if(($tid!=null) && ($tnum == null)){
            $data = $this->get_ticket($tid,null);
            //$this->AQ->DB->insert('removedtickets',$data);
            $this->cancel_ticket($tid,null);
        }else if(($tid ==null) && ($tnum != null)){
            $data = $this->get_ticket($tid,null);
            //$this->AQ->DB->insert('removedtickets',$data);
            $this->cancel_ticket(null,$tnum);
        }

    }
    
}
