<html>
<head>
    <title>Test</title>
</head>
<body>

<!--<form action="tets.php" method="post">
    SSn: <input type="text" name="ssn"><br><br>
    fname: <input type="text" name="fname"><br><br>
    lname: <input type="text" name="lname"><br><br>
    email: <input type="text" name="email"><br><br>
    phone: <input type="text" name="phone"><br><br>
    password : <input type="text" name="password"><br><br>
    <input type="submit">
</form>!-->
<form action="tets.php" method="post">
    Email: <input type="text" name="email"/><br>
    <input type="submit">
</form>
</body>
</html>
<?php
    $date = explode('-',date('y y-m-d'));
    echo $date[0].'<br>'.$date[1].'<br>'.$date[2];
?>