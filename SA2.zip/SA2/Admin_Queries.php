<?php

include_once '../Database/Database_class.php';
class Admin_Queries{
    //put your code here
    private $DB;
    
    function __construct() {
        $this->DB = new Database_class();
    }
    
    public function add_new_user($user){
        $data=array('ssn','fname','lname','email','phone','password');
        $data['ssn']=$user->get_ssn();
        $data['fname']=$user->get_fname();
        $data['lname']=$user->get_lname();
        $data['email']=$user->get_email();
        $data['phone']=$user->get_phone();
        $data['password']=$user->get_password();
        $result= $this->DB->insert('customers', $data);
        if($result){
            return TRUE;
        }
       else {
            return FALSE;
            
       }
    }
    public function add_new_admin($admin){
        $data=array('fname','lname','email','username','password');
        $data['fname']=$admin->get_fname();
        $data['lname']=$admin->get_lname();
        $data['email']=$admin->get_email();
        $data['username']=$admin->get_username();
        $data['password']=$admin->get_password();
        
        $result= $this->DB->insert('admin', $data);
        if($result){
            return TRUE;
        }
       else {
            return FALSE;
            
       }
    }
    
    public function add_new_train($train){
        $tdata  = array('tnum','tname');
        $tdata2 = array('source','destination');
        $tdata3 = array('year','month','day','hour','minute','second');
        $tdata['tnum']=$train->get_tNum();
        $tdata['tname']=$train->get_tname();
        $tdata2['source']=$train->get_source();
        $tdata2['destination']=$train->get_destination();
        $tdata3['year']=$train->train_date->get_year();
        $tdata3['month']=$train->train_date->get_month();
        $tdata3['day']=$train->train_date->get_day();
        $tdata3['hour']=$train->train_date->get_hours();
        $tdata3['minute']=$train->train_date->get_minutes();
        $tdata3['second']=$train->train_date->get_seconds();
        $result= $this->DB->insert('trains', $tdata);
        $result1= $this->DB->insert('trains', $tdata2);
        $result2= $this->DB->insert('trains', $tdata3);
        if($result && $result1 && $result2)
            return TRUE;
       else
            return FALSE;
         
    }
    
    public function add_new_clerk($clerk){
        $data=array('fname','lname','email','password','salary');
        $data['fname']=$clerk->get_fname();
        $data['lname']=$clerk->get_lname();
        $data['email']=$clerk->get_email();
        $data['password']=$clerk->get_password();
        $data['salary']=$clerk->get_salary();
        $result= $this->DB->insert('clerks', $data);
        if($result){
            return TRUE;
        }
       else {
            return FALSE;
            
       }
    }
    public function get_user($tname,$email = null,$id = null){
       if($email == null && $id == null && $tname){
           echo "function got no arguments";
       }else if(($email!=null) && ($id == null)){
           
        $query="SELECT * FROM `$tname` where email='$email'";
        $user_data=$this->DB->get_row($query);
        return $user_data;
       }else if(($email ==null) && ($id != null)){
            $query="SELECT * FROM `$tname` where id='$id'";
        $user_data=$this->DB->get_row($query);
        return $user_data;
       }
           
    }

    /*
     * hena l method de ht4el ay user swa2 kan passenger 2w clerk
     */
    public function remove_user($tname,$umail){
      $query = "DELETE FROM '$tname' where email = '$umail'";
           $query_run = mysqli_run($query);
           if($query_run)
                return true;
            else {
             throw new Exception("nta 4klk keda d5lt ya 2ma l tables 3'lt ya 2ma l mail 3'lt ya 3m l user m4 mwgod asln hwa kan lzmk fe 7aga ya m3lm");   
            }
            
            }
            /*
             * ana hena ma redt4 23ml general method l l remove 34an l semantics bta3 l code
             */
    public function remove_train($tid,$tnum){
       if($tid == null && $tnum == null){
            throw new Exception("Ma td5l rkm ltrain wla l id wla hwa 4o3'l 3lo2");
        }else if($tid != null && $tnum == null) {
             $query = "DELETE FROM 'trains' where email = '$tid'";
           $user_data=$this->DB->get_row($query);
            if($user_data)
                return true;
            else {
             throw new Exception("nta 4klk keda d5lt  l id 3'lt ya 2ma l  id  m4 mwgod asln hwa kan lzmk fe 7aga ya m3lm");   
            }
        }else{
             $query = "DELETE FROM 'trains' where email = '$tnum'";
            $query_run =mysqli_run($query);
            if($query_run)
                return true;
            else {
             throw new Exception("nta 4klk keda d5lt  l num 3'lt ya 2ma l  id num mwgod asln hwa kan lzmk fe 7aga ya m3lm");   
            }
        }
    }
    public function edit_clerk($fname,$lname,$email,$password,$salary,$id){
        $cdata=array('fname'=>$fname,'lname'=>$lname,'email'=>$email,'password'=>$password,'salary'=>$salary);
        $result  = $this->DB->update('clerks',$cdata,$id);
        if($result)
            return true;
        else
            return false;
    }
    public function edit_train($tnum,$tname,$source,$destination,$year,$month,$day,$hour,$minute,$second,$id){
        $tdata  = array('tnum'=>$tnum,'tname'=>$tname);
        $tdata2 = array('source'=>$source,'destination'=>$destination);
        $tdata3 = array('year'=>$year,'month'=>$month,'day'=>$day,'hour'=>$hour,'minute'=>$minute,'second'=>$second);
        $result  = $this->DB->update('trains',$tdata,$id);
        $result2  = $this->DB->update('trains',$tdata2,$id);
        $result3  = $this->DB->update('trains',$tdata3,$id);
    }
            
            }
