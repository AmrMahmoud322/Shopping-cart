<?php
session_start(); /* Session */
$con=mysqli_connect("localhost","root","","pls"); /*Database Connection*/
?>
