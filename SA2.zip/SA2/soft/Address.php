<?php

/**
 * Created by PhpStorm.
 * User: omarabdelaziz
 * Date: 30/04/17
 * Time: 09:21 م
 */
class Address
{
    private $counrty;
    private $state;
    private $city;
    private $postalcode;
    private $street;

    /**
     * @param mixed $counrty
     */
    public function setCounrty($counrty)
    {
        $this->counrty = $counrty;
    }

    /**
     * @return mixed
     */
    public function getCounrty()
    {
        return $this->counrty;
    }

    /**
     * @param mixed $state
     */
    public function setState($state)
    {
        $this->state = $state;
    }
    /**
     * @return mixed
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * @param mixed $city
     */
    public function setCity($city)
    {
        $this->city = $city;
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * @param mixed $postalcode
     */
    public function setPostalcode($postalcode)
    {
        $this->postalcode = $postalcode;
    }

    /**
     * @return mixed
     */
    public function getPostalcode()
    {
        return $this->postalcode;
    }

    /**
     * @param mixed $street
     */
    public function setStreet($street)
    {
        $this->street = $street;
    }

    /**
     * @return mixed
     */
    public function getStreet()
    {
        return $this->street;
    }
}