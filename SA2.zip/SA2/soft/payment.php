<?php
include_once '../Database/Payment_Queries.php';
include_once '../Database/DbConnection.php';
class payment 
{
    public $fname;
    private $lname;//rkm l bta2a
    private $address;//first name
    private $city;//last name
    private $phone;
    private $quantity;
    private $item_name;
    private $card_number;
    private $expiration_date;
    private $card_code;

    public $date;
    public $db;



    public function __construct()
    {
       // $this->date = new Date();
        $this->db = new DbConnection();
      //  $this->address = new Address();
        $this->PQ = new Payment_Queries();
    }


     public function setFname($fname)
    {
        $this->fname = $fname;
    }
     public function getFname()
    {
        return $this->fname;
    }


     public function setLname($lname)
    {
        $this->lname = $lname;
    }
     public function getLname()
    {
        return $this->lname;
    }


     public function setAddress($address)
    {
        $this->address = $address;
    }
     public function getAddress()
    {
        return $this->address;
    }


     public function setCity($city)
    {
        $this->city = $city;
    }
     public function getCity()
    {
        return $this->city;
    }


     public function setPhone($phone)
    {
        $this->phone = $phone;
    }
     public function getPhone()
    {
        return $this->phone;
    }


     public function setQuantity($quantity)
    {
        $this->quantity = $quantity;
    }

     public function getQuantity()
    {
        return $this->quantity;
    }



     public function setItem_name($item_name)
    {
        $this->item_name = $item_name;
    }
         public function getItem_name()
    {
        return $this->item_name;
    }



     public function setCard_number($card_number)
    {
        $this->card_number = $card_number;
    }

     public function getCard_number()
    {
        return $this->card_number;
    }


     public function setExpiration_date($expiration_date)
    {
        $this->expiration_date = $expiration_date;
    }
     public function getExpiration_date()
    {
        return $this->expiration_date;
    }



     public function setCard_code($card_code)
    {
        $this->card_code = $card_code;
    }
     public function getCard_code()
    {
        return $this->card_code;
    }


     public function add_payment(payment $payment){
         if ($this->PQ->add_new_payment($payment)) {
            return true;
        } else {
            return false;
        }
    }
}