
 <?php
   include_once '../Database/User_Queries.php';
if(isset($_POST['ticket-id'])) {
    $search = $_POST['ticket-id'];
    $user = new User_Queries();
    $user->view_ticket($search);
    
    if($user->view_ticket($user)){
        header('location: ../train-system/ClerkCheckTicket.php');
    }else{
        header('location: ../train-system/ClerkCheckTicket.php');
    }
}


                       ?>