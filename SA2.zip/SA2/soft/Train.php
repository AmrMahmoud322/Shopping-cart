<?php
include_once 'Time.php';
class Train
{
    private $train_num;
    private $train_name;
    private $source;
    private $destination;
    private $num_of_steps;
    public $moving_date;
    public $moving_time;

    public function __construct()
    {
        $this->moving_date= new Date();
        $this->moving_time = new Time();

    }

    /**
     * @param mixed $train_num
     */
    public function setTrainNum($train_num)
    {
        $this->train_num = $train_num;
    }

    /**
     * @return mixed
     */
    public function getTrainNum()
    {
        return $this->train_num;
    }

    /**
     * @param mixed $train_name
     */
    public function setTrainName($train_name)
    {
        $this->train_name = $train_name;
    }

    /**
     * @return mixed
     */
    public function getTrainName()
    {
        return $this->train_name;
    }

    /**
     * @param mixed $source
     */
    public function setSource($source)
    {
        $this->source = $source;
    }

    /**
     * @return mixed
     */
    public function getSource()
    {
        return $this->source;
    }

    /**
     * @param mixed $destination
     */
    public function setDestination($destination)
    {
        $this->destination = $destination;
    }

    /**
     * @return mixed
     */
    public function getDestination()
    {
        return $this->destination;
    }

    /**
     * @param mixed $num_of_steps
     */
    public function setNumOfSteps($num_of_steps)
    {
        $this->num_of_steps = $num_of_steps;
    }

    /**
     * @return mixed
     */
    public function getNumOfSteps()
    {
        return $this->num_of_steps;
    }


}