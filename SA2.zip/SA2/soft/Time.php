<?php

/**
 * Created by PhpStorm.
 * User: omarabdelaziz
 * Date: 01/05/17
 * Time: 12:40 ص
 */
class Time
{
    private $hour;
    private $minute;
    private $second;
    /**
     * @param mixed $hour
     */
    public function setHour($hour)
    {
        $this->hour = $hour;
    }

    /**
     * @return mixed
     */
    public function getHour()
    {
        return $this->hour;
    }

    /**
     * @param mixed $minute
     */
    public function setMinute($minute)
    {
        $this->minute = $minute;
    }

    /**
     * @return mixed
     */
    public function getMinute()
    {
        return $this->minute;
    }

    /**
     * @param mixed $second
     */
    public function setSecond($second)
    {
        $this->second = $second;
    }

    /**
     * @return mixed
     */
    public function getSecond()
    {
        return $this->second;
    }

}