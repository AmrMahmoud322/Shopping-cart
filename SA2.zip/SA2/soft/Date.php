<?php

/**
 * Created by PhpStorm.
 * User: omarabdelaziz
 * Date: 30/04/17
 * Time: 11:48 م
 */
class Date
{
    private $year;
    private $month;
    private $day;


    /**
     * @param mixed $year
     */
    public function setYear($year)
    {
        $this->year = $year;
    }

    /**
     * @return mixed
     */
    public function getYear()
    {
        return $this->year;
    }

    /**
     * @param mixed $month
     */
    public function setMonth($month)
    {
        $this->month = $month;
    }

    /**
     * @return mixed
     */
    public function getMonth()
    {
        return $this->month;
    }

    /**
     * @param mixed $day
     */
    public function setDay($day)
    {
        $this->day = $day;
    }
    /**
     * @return mixed
     */
    public function getDay()
    {
        return $this->day;
    }


}