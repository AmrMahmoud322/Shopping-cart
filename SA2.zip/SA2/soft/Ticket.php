<?php

/**
 * Created by PhpStorm.
 * User: omarabdelaziz
 * Date: 01/05/17
 * Time: 12:50 م
 */
class Ticket
{
    public $tid;
    private $ticket_num;//htkon l id;
    private $traveling_class;
    public $traveling_date;
    public $traveling_time;
    public $train;
    private $price;


    public function __construct()
    {
     $this->traveling_date = new Date();
     $this->traveling_time = new Time();
     $this->train =new Train();
    }

    /**
     * @param mixed $ticket_num
     */
    public function setTicketNum($ticket_num)
    {
        $this->ticket_num = $ticket_num;
    }

    /**
     * @param mixed $traveling_class
     */
    public function setTravelingClass($traveling_class)
    {
        $this->traveling_class = $traveling_class;
    }

    /**
     * @param mixed $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }

    /**
     * @return mixed
     */
    public function getTicketNum()
    {
        return $this->ticket_num;
    }

    /**
     * @return mixed
     */
    public function getTravelingClass()
    {
        return $this->traveling_class;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }
}