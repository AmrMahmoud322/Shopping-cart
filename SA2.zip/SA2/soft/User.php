<?php

/**
 * Created by PhpStorm.
 * User: omarabdelaziz
 * Date: 30/04/17
 * Time: 03:35 م
 */
include_once '../soft/Address.php';
include_once '../soft/Date.php';
include_once '../Database/DbConnection.php';
class User
{
    private $id;
    private $ssn;//rkm l bta2a
    private $fname;//first name
    private $lname;//last name
    private $email;
    private $phone;
    private $password;
    public $date;
    public $db;
    public $address;
    public function __construct()
    {
        $this->date = new Date();
        $this->db = new DbConnection();
        $this->address = new Address();
    }



    /**
     * @param mixed $ssn
     */

    public function setSsn($ssn)
    {
        $this->ssn = $ssn;
    }

    /**
     * @return mixed
     */
    public function getSsn()
    {
        return $this->ssn;
    }

    /**
     * @param mixed $fname
     */
    public function setFname($fname)
    {
        $this->fname = $fname;
    }

    /**
     * @return mixed
     */
    public function getFname()
    {
        return $this->fname;
    }

    /**
     * @param mixed $lname
     */
    public function setLname($lname)
    {
        $this->lname = $lname;
    }

    /**
     * @return mixed
     */
    public function getLname()
    {
        return $this->lname;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $phone
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    }
    /**
     * @return mixed
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    //hnbd2 l function bta3 l login

    public function logIn($email, $password){
        $user_data = $this->db->get_user_by_email_password($email,$password,'customers');
        if($user_data){
          //  $this->id=$user_data['id'];
            $this->fname=$user_data['fname'];
            $this->lname=$user_data['lname'];
            $this->email=$user_data['email'];
            $this->password=$user_data['password'];
      //      $this->username=$user_data['username'];
      //      $this->user_type= new ..\Database\User_Type_Queries($user_data['user_type_id']);
            session_start();
            $_SESSION['id']=$user_data['id'];
            $_SESSION['fname']=$user_data['fname'];;
            $_SESSION['user_type_id']=$user_data['user_type_id'];
            return TRUE;
        }
        else{
            return FALSE;
        }
    }

    //l log out function hn destroy l session
     public function logOut(){
         session_destroy();
         header("location: index.php");
     }

}